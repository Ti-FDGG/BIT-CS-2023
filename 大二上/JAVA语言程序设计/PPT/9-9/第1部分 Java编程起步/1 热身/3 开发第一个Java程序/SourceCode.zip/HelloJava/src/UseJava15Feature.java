public class UseJava15Feature {
    public static void main(String[] args) {
        var info= """
                好好学习，
                天天向上
                """;
        System.out.println(info);
    }
}
