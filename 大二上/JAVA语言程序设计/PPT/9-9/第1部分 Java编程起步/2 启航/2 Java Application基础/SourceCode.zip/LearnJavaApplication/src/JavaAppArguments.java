
public class JavaAppArguments {
    public static void main(String[] args) {
        System.out.println("参数个数：" + args.length);
        //使用foreach循环打印出所有接收到的运行时参数
        for (String arg : args) {
            System.out.println(arg);
        }
    }
}
