import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;

public class NumberFormatDemo {

    public static void main(String[] args) {
        //将要被格式化的数字
        double doubleValue = 10_000_000.53;

        //按节显示数字
        NumberFormat numF = NumberFormat.getNumberInstance();
        //Number: 10,000,000.53
        System.out.println("Number: " + numF.format(doubleValue));

        //将浮点数四舍五入为整数
        NumberFormat intF = NumberFormat.getIntegerInstance();
        //Number: 10,000,001
        System.out.println("Number: " + intF.format(doubleValue));

        //关闭“按节显示功能”，显示“原始形式”的数值
        intF.setGroupingUsed(false);
        //Number: 10000001
        System.out.println("Number: " + intF.format(doubleValue));

        //不同的国家，会有不同的文化，通常会使用不同的方式，显示普通数字和金额数字
        //cn代表咱们中国
        Locale locale = new Locale("zh", "CN");
        NumberFormat localeFormatter = NumberFormat.getNumberInstance(locale);
        //按照中国惯例显示普通数字
        //Number: 10,000,000.53
        System.out.println("Number: " + localeFormatter.format(doubleValue));
        //按照人民币格式显示金额
        NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance();
        //¥10,000,000.53
        System.out.println(currencyFormatter.format(doubleValue));



    }
}
