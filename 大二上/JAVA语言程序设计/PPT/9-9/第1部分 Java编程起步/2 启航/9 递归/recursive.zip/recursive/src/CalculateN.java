import java.math.BigInteger;
import java.util.Scanner;

public class CalculateN {

    public static void main(String[] args) {
        System.out.print("请输入N：");
        Scanner scanner = new Scanner(System.in);
        int number = scanner.nextInt();
        //N值较大时，会出错
        //System.out.println(number + "! = " + calculateN(number));
        //能够很好地解决大数问题
        System.out.println(number + "! = " + calculateN2(number));
    }

    //使用递归的方式计算N的阶乘
    public static long calculateN(int n) {
        //数学上规定：1!=1 , 0!=1
        if (n == 1 || n == 0) {
            return 1;
        }
        //使用递归的方式计算N的阶乘
        return n * calculateN(n - 1);
    }

    //使用BigInteger解决求大数的阶乘问题
    public static BigInteger calculateN2(int n) {
        if (n == 1 || n == 0) {
            return BigInteger.valueOf(1);
        }
        return BigInteger
                .valueOf(n)
                .multiply(calculateN2((n - 1)));
    }
}
