package com.jinxuliang.javafxshapes;

import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.Background;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Arc;
import javafx.scene.shape.ArcType;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class ChangingFace extends Application {
    @Override
    public void start(Stage stage) throws Exception {
        //脸
        Circle face = new Circle(125, 125, 80);
        face.setFill(Color.YELLOW);
        face.setStroke(Color.RED);
        //两只眼
        Circle rightEye = new Circle(86, 100, 10);
        rightEye.setFill(Color.YELLOW);
        rightEye.setStroke(Color.BLUE);

        Circle leftEye = new Circle(162, 100, 10);
        leftEye.setFill(Color.YELLOW);
        leftEye.setStroke(Color.BLUE);
        //嘴
        Arc mouth = new Arc(125, 150, 45, 35, 0, -180);
        mouth.setFill(Color.YELLOW);
        mouth.setStroke(Color.BLUE);
        mouth.setType(ArcType.OPEN);
        //说明信息
        Text caption = new Text(68, 240, "苦与乐，悲与欢");
        caption.setFill(Color.BLUE);
        caption.setFont(Font.font("Verdana", 15));
        //组合为一张脸
        Group group = new Group(face, rightEye, leftEye, mouth, caption);

        //使用HBox水平排列两个按钮
        HBox buttonBox = new HBox(10);
        buttonBox.setAlignment(Pos.CENTER);
        Button smileButton = new Button("笑");
        Button frownButton = new Button("悲");
        //点击时更换表情
        smileButton.setOnAction(e -> mouth.setLength(-180));
        frownButton.setOnAction(e -> mouth.setLength(180));
        buttonBox.getChildren().addAll(smileButton, frownButton);

        VBox root = new VBox(10);
        root.setBackground(Background.EMPTY);
        root.setAlignment(Pos.CENTER);
        root.getChildren().addAll(buttonBox, group);

        Scene scene = new Scene(root, 250, 275, Color.YELLOW);
        stage.setScene(scene);
        stage.setTitle("变脸");
        stage.show();

    }

    public static void main(String[] args) {
        launch(args);
    }
}
