module com.jinxuliang.javafxshapes {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.jinxuliang.javafxshapes to javafx.fxml;
    exports com.jinxuliang.javafxshapes;
}