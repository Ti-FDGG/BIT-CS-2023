package com.jinxuliang.javafxshapes;

import javafx.application.Application;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.shape.Line;
import javafx.scene.shape.StrokeLineCap;
import javafx.stage.Stage;

public class LineShapes extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {

        //图形对象的容器，通常选择轻量级的Group
        Group root = new Group();

        //通过指定起始点和终点坐标确定一条直线
        Line line1 = new Line(20, 50, 400, 50);
        //设定使用的线型
        line1.setStroke(Color.GREEN);
        //指定线条宽度
        line1.setStrokeWidth(10);

        Line line2 = new Line(20, 80, 400, 80);
        line2.setStroke(Color.BLUE);
        line2.setStrokeWidth(10);
        line2.setStrokeLineCap(StrokeLineCap.ROUND);

        Line line3 = new Line(20, 110, 400, 110);
        line3.setStroke(Color.RED);
        line3.getStrokeDashArray().addAll(20d, 10d);
        line3.setStrokeWidth(5);

        root.getChildren().addAll(line1, line2, line3);

        Scene scene = new Scene(root, 430, 140);
        primaryStage.setScene(scene);
        primaryStage.setTitle("使用Line");
        primaryStage.show();


    }

    public static void main(String[] args) {
        launch(args);
    }
}
