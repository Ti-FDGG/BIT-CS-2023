package com.jinxuliang.javafxshapes;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Ellipse;
import javafx.stage.Stage;

public class BeautifulEllipse extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) {

        Pane panel = new Pane();
        for (int i = 0; i < 360; i++) {
            var e = new Ellipse(150, 110, 100, 50);
            e.setStroke(Color.color(Math.random(), Math.random(), Math.random()));
            e.setFill(Color.WHITE);
            e.setRotate(i * 180 / 360);
            panel.getChildren().add(e);
        }

        Scene scene = new Scene(panel, 300, 230);
        stage.setScene(scene);
        stage.setTitle("美丽的椭圆");
        stage.show();
    }
}
