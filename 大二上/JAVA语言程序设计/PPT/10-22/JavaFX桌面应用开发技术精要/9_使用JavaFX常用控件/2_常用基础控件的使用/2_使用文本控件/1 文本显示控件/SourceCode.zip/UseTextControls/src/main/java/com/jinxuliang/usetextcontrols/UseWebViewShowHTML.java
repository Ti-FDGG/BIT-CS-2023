package com.jinxuliang.usetextcontrols;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;

public class UseWebViewShowHTML extends Application {
    @Override
    public void start(Stage primaryStage) throws Exception {

        VBox vBox = new VBox();
        vBox.setSpacing(10);
        vBox.setAlignment(Pos.CENTER);
        vBox.setPadding(new Insets(10));

        WebView webView = new WebView();
        WebEngine webEngine = webView.getEngine();
        String html = """
                <h2>这是标题</h2>
                <p>这是段落</p>
                """;
        webEngine.loadContent(html, "text/html");

        vBox.getChildren().add(webView);
        Scene scene = new Scene(vBox, 360, 200);

        primaryStage.setScene(scene);
        primaryStage.setTitle("使用WebView显示HTML文本");
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
