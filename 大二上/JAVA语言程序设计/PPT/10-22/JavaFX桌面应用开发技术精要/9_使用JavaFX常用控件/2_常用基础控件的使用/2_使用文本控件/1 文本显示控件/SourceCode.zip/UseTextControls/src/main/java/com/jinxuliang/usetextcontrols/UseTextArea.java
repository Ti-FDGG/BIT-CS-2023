// TextAreaTest.java
package com.jinxuliang.usetextcontrols;

import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class UseTextArea extends Application {
	public static void main(String[] args) {
		Application.launch(args);
	}

	@Override
	public void start(Stage stage) {
		TextField title = new TextField("《蜂》唐·罗隐");
		title.setPromptText("诗的标题");
		
		TextArea poem = new TextArea();
		//默认显示10行，每行20个字符
		poem.setPrefColumnCount(20);
		poem.setPrefRowCount(10);
		//当没有显示文本时，显示此提示信息
		poem.setPromptText("诗的主体");
		//设定显示内容
		poem.appendText("""
				不论平地与山尖，
				无限风光尽被占。
				采得百花成蜜后，
				为谁辛苦为谁甜？""");
	    
		Button printBtn = new Button("打印诗歌的相关信息");
		printBtn.setOnAction(e -> printTextAreaInfo(poem));

		VBox root = new VBox(new Label("标题:"), title,
		                     new Label("内容:"), poem, printBtn);
		root.setSpacing(5);
		root.setStyle("-fx-padding: 10;" + 
		              "-fx-border-style: solid inside;" + 
		              "-fx-border-width: 2;" +
		              "-fx-border-insets: 5;" + 
		              "-fx-border-radius: 5;" + 
		              "-fx-border-color: blue;");

		Scene scene = new Scene(root);      
		stage.setScene(scene);      
		stage.setTitle("使用TextArea编辑诗歌");
		stage.show();
	}
	
	public void printTextAreaInfo(TextArea poem) {
		System.out.println("长度: " + poem.getLength());
		System.out.println("内容:\n" + poem.getText());
		System.out.println();
		//打印段落信息
		ObservableList<CharSequence> list = poem.getParagraphs();
		int size = list.size();
		System.out.println("段落数:" + size);
		for(int i = 0; i < size; i++) {
			CharSequence cs = list.get(i);
	        System.out.println("段落 #" + (i + 1) +
	                           ", 字符数="  + cs.length());
			System.out.println(cs);
		}
	}
}
