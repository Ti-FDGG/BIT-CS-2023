package com.jinxuliang.usetextcontrols;

import javafx.application.Application;
import javafx.geometry.VPos;
import javafx.scene.Scene;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class UseText extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    public void start(Stage primaryStage) {

        Text text = new Text("这是一个JavaFX的Text控件，\n它有多行。");
        //字体设置为“仿宋”，“粗体”，大小为40
        text.setFont(Font.font("FZYaoTi", FontWeight.BOLD,40));
        text.setFill(Color.YELLOW);
        text.setStroke(Color.GREEN);

        text.setTextOrigin(VPos.CENTER);
        Scene scene = new Scene(new VBox(text),500,100);
        primaryStage.setTitle("Text控件示例");
        primaryStage.setScene(scene);
        primaryStage.show();

    }
}
