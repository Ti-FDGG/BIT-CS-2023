module com.jinxuliang.usetextcontrols {
    requires javafx.controls;
    requires javafx.fxml;
    requires javafx.web;

    opens com.jinxuliang.usetextcontrols to javafx.fxml;
    exports com.jinxuliang.usetextcontrols;
}