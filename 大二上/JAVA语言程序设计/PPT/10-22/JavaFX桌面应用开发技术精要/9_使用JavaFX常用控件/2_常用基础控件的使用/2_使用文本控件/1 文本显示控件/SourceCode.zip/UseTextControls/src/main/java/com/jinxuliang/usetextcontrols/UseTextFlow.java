package com.jinxuliang.usetextcontrols;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;
import javafx.stage.Stage;

public class UseTextFlow extends Application {
    public static void main(String[] args) {
        Application.launch(args);
    }

    @Override
    public void start(Stage stage) {

        //创建三个Text对象
        Text text1 = new Text("TextFlow是一种特殊的文本容器! ");
        text1.setFill(Color.RED);
        text1.setFont(Font.font("Arial", FontWeight.BOLD, 12));

        Text text2 = new Text("它能够显示多格式的文本");
        text2.setFill(Color.BLUE);

        Text text3 = new Text("\n这是新的一段，是使用\\n来创建的 ");

        // 组合三个Text构建TextFlow
        TextFlow root = new TextFlow(text1, text2, text3);

        //将一个按钮加入到TextFlow中
        Button btnInText = new Button("点击我新加一行");
        btnInText.setOnAction(e -> {
            Text newText = new Text("\n使用代码新加的文本");
            newText.setFont(new Font(20));
            root.getChildren().add(newText);
        });

        root.getChildren().add(btnInText);

        // 设定显示宽度和行间距
        root.setPrefWidth(300);
        root.setLineSpacing(5);

        root.setStyle("-fx-padding: 10;" +
                "-fx-border-style: solid inside;" +
                "-fx-border-width: 2;" +
                "-fx-border-insets: 5;" +
                "-fx-border-radius: 5;" +
                "-fx-border-color: blue;");

        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("TextFlow使用示例");
        stage.show();
    }
}
