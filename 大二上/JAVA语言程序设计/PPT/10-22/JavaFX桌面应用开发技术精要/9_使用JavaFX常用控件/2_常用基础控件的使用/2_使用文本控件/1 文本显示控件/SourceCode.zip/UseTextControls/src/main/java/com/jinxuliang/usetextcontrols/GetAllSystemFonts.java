package com.jinxuliang.usetextcontrols;

import javafx.scene.text.Font;

public class GetAllSystemFonts {
    public static void main(String[] args) {
        //获取字体家族
        Font.getFamilies().forEach(System.out::println);
    }
}
