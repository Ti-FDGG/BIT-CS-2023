package com.jinxuliang.usetextcontrols;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.layout.VBox;
import javafx.scene.web.HTMLEditor;
import javafx.stage.Stage;

public class UseHtmlEditor extends Application {

    public static void main(String[] args) {
        launch(args);
    }

    public void start(Stage primaryStage) {

        //实例化一个HTMLEditor控件
        HTMLEditor htmlEditor = new HTMLEditor();
        //追加到VBox中
        VBox vBox = new VBox(htmlEditor);
        vBox.setPadding(new Insets(10));
        vBox.setSpacing(10);
        Button btnGetHTML = new Button("获取HTML文本");
        btnGetHTML.setOnAction(e -> {
            System.out.println(htmlEditor.getHtmlText());
        });

        vBox.getChildren().add(btnGetHTML);
        Scene scene = new Scene(vBox);

        primaryStage.setScene(scene);
        primaryStage.setTitle("使用HtmlEditor编辑HTML文本");

        primaryStage.show();
    }
}
