package com.jinxuliang.usetextcontrols;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.text.Font;
import javafx.stage.Stage;

import java.io.FileInputStream;

public class UseLabel extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        primaryStage.setTitle("标签控件");

        //注意：路径中不能有空格
        var imageUrl = UseLabel.class.getResource("icon.png");
        FileInputStream input = new FileInputStream(imageUrl.getPath());
        Image image = new Image(input);
        ImageView imageView = new ImageView(image);
        imageView.setFitWidth(30);
        imageView.setFitHeight(30);

        //Label可以集成ImagaView显示一个图标
        Label label = new Label("My Label", imageView);
        label.setFont(new Font("Arial", 24));
        label.setPadding(new Insets(20));

        Scene scene = new Scene(label);
        primaryStage.setScene(scene);
        primaryStage.show();
    }
}
