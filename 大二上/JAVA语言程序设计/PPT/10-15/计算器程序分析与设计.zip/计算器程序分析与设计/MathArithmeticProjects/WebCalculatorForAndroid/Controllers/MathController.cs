﻿using MathArithmetic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using WebCalculatorForAndroid.Models;

namespace WebCalculatorForAndroid.Controllers
{
    public class MathController : ApiController
    {
        [HttpGet]
        public HttpResponseMessage Calculate(String expr)
        {
            if (String.IsNullOrEmpty(expr))
            {
                String message = "表达式为空";
                return Request.CreateErrorResponse(HttpStatusCode.BadRequest, message);
            }
            try
            {
                expr = PreProcess.ClearAllSpace(expr);
                PreProcess.CheckExprValidate(expr);
                InfixAlgorithm calculator = new InfixAlgorithm();

                double result = calculator.Calculate(expr);
                CalculateResult calculateResult = new CalculateResult()
                {
                    Result = result,
                    Expression = expr
                };
                return Request.CreateResponse<CalculateResult>(HttpStatusCode.OK, calculateResult);
            }
            catch (CalculatorException e)
            {
                return Request.CreateErrorResponse(HttpStatusCode.InternalServerError, e.Message);
            }
        }
    }
}
