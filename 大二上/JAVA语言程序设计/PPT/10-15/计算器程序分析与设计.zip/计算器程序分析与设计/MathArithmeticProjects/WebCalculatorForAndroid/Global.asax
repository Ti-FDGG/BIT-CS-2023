﻿<%@ Application Codebehind="Global.asax.cs" Inherits="WebCalculatorForAndroid.WebApiApplication" Language="C#" %>
