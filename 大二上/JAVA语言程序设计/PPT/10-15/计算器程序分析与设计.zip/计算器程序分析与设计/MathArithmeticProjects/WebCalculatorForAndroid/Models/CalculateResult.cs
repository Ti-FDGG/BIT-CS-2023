﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebCalculatorForAndroid.Models
{
    public class CalculateResult
    {
        public String Expression { get; set; }
        public double Result { get; set; }
    }
}