﻿@using $rootnamespace$.Areas.HelpPage.ModelDescriptions
@model CollectionModelDescription
@if (Model.ElementDescription is ComplexTypeModelDescription)
{
    @Html.DisplayFor(m => m.ElementDescription)
}