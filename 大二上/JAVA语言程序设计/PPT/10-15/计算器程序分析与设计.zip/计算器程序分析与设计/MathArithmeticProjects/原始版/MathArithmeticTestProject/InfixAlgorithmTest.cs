﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using MathArithmetic;

namespace MathArithmeticTestProject
{
    [TestClass]
    public class InfixAlgorithmTest
    {

        #region Additional test attributes
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class

        private static IAlgorithm target = null;

        [ClassInitialize()]
        public static void MyClassInitialize(TestContext testContext)
        {
            target = new InfixAlgorithm();
        }
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        //public void MyTestInitialize()
        //{
        //}
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion

        [TestMethod]
        public void CalculateTest()
        {
            //InfixAlgorithm target = new InfixAlgorithm();
            string expr = (10 + 30 * 2).ToString();
            double expected = 70;
            double actual;
            actual = target.Calculate(expr);
            Assert.AreEqual(expected, actual, 1e-6);
        }

        public TestContext TestContext { get; set; }

        [TestMethod()]
        [DataSource(
            "System.Data.SqlClient", @"Data Source=localhost\SQLEXPRESS;
		     Initial Catalog=CalculateUnitTest;	Integrated Security=True",
             "TestCases", DataAccessMethod.Sequential)]
        public void CalculateTest2()
        {
           // InfixAlgorithm target = new InfixAlgorithm();
            double actual =
                target.Calculate(TestContext.DataRow["Expression"].ToString());
            double expected =
                Convert.ToDouble(TestContext.DataRow["ExpectedValue"]);
            Assert.AreEqual(expected, actual,
                  1e-6, "MathArithmetic.InfixAlgorithm.Calculate 未返回所需的值。");
        }
    }
}
