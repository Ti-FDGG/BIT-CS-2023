﻿using MathArithmetic;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using WebCalculator.Models;

namespace WebCalculator.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }


        public ActionResult WebCalculate()
        {
            CalculateResult result = new CalculateResult();
            return View(result);
        }
        [HttpPost]
        public ActionResult WebCalculate(CalculateResult result)
        {
            if (result == null)
            {
                ModelState.AddModelError("resultError", "MVC未能创建CalculateResult对象");
            }
            if (ModelState.IsValid)
            {
                try
                {
                    String expr = PreProcess.ClearAllSpace(result.Expression);
                    PreProcess.CheckExprValidate(expr);
                    InfixAlgorithm calculator = new InfixAlgorithm();
                    CalculateResult calculateResult = new CalculateResult()
                    {
                        Result = calculator.Calculate(expr),
                        Expression = expr
                    };
                    return View(calculateResult);
                }
                catch (CalculatorException e)
                {
                    ModelState.AddModelError("Expression", e.Message);
                }
            }

            return View(result);
        }


        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }
    }
}