﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace WebCalculator.Models
{
    public class CalculateResult
    {
        [Required(ErrorMessage = "表达式不能为空")]
        [Display(Name = "输入一个四则运算表达式")]
        public String Expression { get; set; }
        [Display(Name = "计算结果")]
        public double Result { get; set; }
    }
}