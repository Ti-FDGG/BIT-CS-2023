package com.jinxuliang;

import java.time.Duration;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Set;
import java.util.TreeSet;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.locks.ReentrantLock;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.IntStream;

public class MillionVirtualThreads {

    public static final Pattern POOL_PATTERN =
          Pattern.compile("ForkJoinPool-[\\d?]");
    public static final Pattern WORKER_PATTERN =
          Pattern.compile("worker-[\\d?]+");


    public static void main(String[] args) throws InterruptedException {
        //保存线程池的名字
        Set<String> poolNames = ConcurrentHashMap.newKeySet();
        //保存线程池中工作线程的名字
        Set<String> pThreadNames = ConcurrentHashMap.newKeySet();
        //将创建100万个虚拟线程
        int N_THREADS = 1_000_000;

        var threads = IntStream.range(0, N_THREADS)
              .mapToObj(i -> Thread.ofVirtual()
                    .unstarted(
                          () -> {
                              //获取线程池名字
                              String poolName = readPoolName();
                              poolNames.add(poolName);
                              //获取工作线程名字
                              String workerName = readWorkerName();
                              pThreadNames.add(workerName);
                          }
                    )
              )
              .toList();

        //启动所有虚拟线程，等待其运行结束，并计算运行时间
        Instant begin = Instant.now();
        for (var thread : threads) {
            thread.start();
        }
        for (var thread : threads) {
            thread.join();
        }
        Instant end = Instant.now();

        System.out.println("# 虚拟线程个数 = " + N_THREADS);
        System.out.println("# 本机CPU核数 = " + Runtime.getRuntime().availableProcessors());
        System.out.println(" 耗费时间 = " + Duration.between(begin, end).toMillis() + "ms");
        System.out.println("### 线程池名字");
        poolNames.forEach(System.out::println);
        System.out.println("### 使用的工作线程个数: " + pThreadNames.size());
    }


    private static String readWorkerName() {
        String name = Thread.currentThread().toString();
        Matcher workerMatcher = WORKER_PATTERN.matcher(name);
        if (workerMatcher.find()) {
            return workerMatcher.group();
        }
        return "not found";
    }

    private static String readPoolName() {
        String name = Thread.currentThread().toString();
        Matcher poolMatcher = POOL_PATTERN.matcher(name);
        if (poolMatcher.find()) {
            return poolMatcher.group();
        }
        return "pool not found";
    }
}
