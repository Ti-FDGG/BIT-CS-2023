package com.jinxuliang;
import jdk.internal.vm.Continuation;
import jdk.internal.vm.ContinuationScope;

//此示例在运行时，需要加入以下参数：
//--enable-preview --add-exports java.base/jdk.internal.vm=ALL-UNNAMED
public class PlayWithContinuation {
    public static void main(String[] args) {
        //任务的“挂起”与“恢复”，是在一个ContinuationScope中完成的
        var scope = new ContinuationScope("My scope");
        var continuation = new Continuation(
                scope,
                () -> {
                    System.out.println("continuation开始执行，之后调用yield()方法‘挂起’");
                    //这里“挂起”，释放当前工作线程
                    Continuation.yield(scope);
                    System.out.println("‘挂起’结束，恢复执行");
                });

        System.out.println("main方法执行");
        continuation.run();
        System.out.println("回到main方法执行");
        continuation.run();
        System.out.println("回到main方法执行");
    }
}
