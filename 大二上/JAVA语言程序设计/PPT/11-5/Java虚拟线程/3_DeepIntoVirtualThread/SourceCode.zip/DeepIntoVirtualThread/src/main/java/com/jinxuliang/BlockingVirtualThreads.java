package com.jinxuliang;

import java.time.Duration;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;

public class BlockingVirtualThreads {
    public static void main(String[] args) throws InterruptedException {

        Runnable multiPhaseTask =
                () -> {
                    System.out.println("开始：" + Thread.currentThread());
                    //第一阶段
                    sleepFor(10, ChronoUnit.MICROS);
                    System.out.println("第一阶段结束：" + Thread.currentThread());
                    //第二阶段
                    sleepFor(10, ChronoUnit.MICROS);
                    System.out.println("第二阶段结束：" + Thread.currentThread());
                    //第三阶段
                    sleepFor(10, ChronoUnit.MICROS);
                    System.out.println("所有任务全部完成:" + Thread.currentThread());
                };

        Runnable otherTask =
                () -> {
                    //不干啥正经事，空转，就为了模拟多任务的场景，
                    int count = 0;
                    sleepFor(10, ChronoUnit.MICROS);
                    do {
                        count++;
                    } while (count <= 100_0000);
                };

        int N_THREADS = 10;
        var threads = new ArrayList<Thread>();
        //第一个虚拟线程执行multiPhaseTask，其余的线程，执行otherTask
        for (int index = 0; index < N_THREADS; index++) {
            var thread = index == 0 ?
                    Thread.ofVirtual().unstarted(multiPhaseTask) :
                    Thread.ofVirtual().unstarted(otherTask);
            threads.add(thread);
        }
        //启动所有虚拟线程执行
        for (Thread thread : threads) {
            thread.start();
        }
        //等待所有虚拟线程执行完毕
        for (Thread thread : threads) {
            thread.join();
        }
    }

    //休眠指定长的时间
    private static void sleepFor(int amount, ChronoUnit unit) {
        try {
            Thread.sleep(Duration.of(amount, unit));
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
