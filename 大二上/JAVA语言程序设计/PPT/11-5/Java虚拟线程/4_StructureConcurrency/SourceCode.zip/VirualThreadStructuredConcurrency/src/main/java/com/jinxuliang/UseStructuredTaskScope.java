package com.jinxuliang;

import java.util.concurrent.Callable;
import java.util.concurrent.StructuredTaskScope;

public class UseStructuredTaskScope {


    public static void main(String[] args) {

        System.out.println(Thread.currentThread() + ":main()开始");
        allSuccess();
//        stepByStep();
//        shutDownOnSuccesss();
//        shutDownOnFailure();
        System.out.println(Thread.currentThread() + ":main()结束");
    }

    //分阶段执行的任务
    private static void stepByStep() {
        try (var scope = new StructuredTaskScope<String>()) {
            var t1 = scope.fork(MyAsyncTask.task1);
            var t2 = scope.fork(MyAsyncTask.task2);
            scope.join();
            System.out.println("\n第一阶段完成...");
            System.out.println("任务一状态：" + t1.state());
            if (t1.state() == StructuredTaskScope.Subtask.State.SUCCESS) {
                System.out.println(t1.get());
            }
            System.out.println("任务二状态：" + t2.state());
            if (t2.state() == StructuredTaskScope.Subtask.State.SUCCESS) {
                System.out.println(t2.get());
            }
            var t3 = scope.fork(MyAsyncTask.task3);
            scope.join();
            System.out.println("\n第二阶段完成...");
            System.out.println("任务三状态：" + t3.state());
            if (t3.state() == StructuredTaskScope.Subtask.State.SUCCESS) {
                System.out.println(t3.get());
            }
        } catch (InterruptedException e) {
            System.out.println(e.getMessage());
        }
    }

    //所有任务均成功
    private static void allSuccess() {
        try (var scope = new StructuredTaskScope<String>()) {
            //启动三个异步任务
            var t1 = scope.fork(MyAsyncTask.task1);
            var t2 = scope.fork(MyAsyncTask.task2);
            var t3 = scope.fork(MyAsyncTask.task3);
            //等待所有异步任务的完成
            scope.join();
            //检查每个异步任务的状态，如果成功，取出结果
            System.out.println("任务一状态：" + t1.state());
            if (t1.state() == StructuredTaskScope.Subtask.State.SUCCESS) {
                System.out.println(t1.get());
            }
            System.out.println("任务二状态：" + t2.state());
            if (t2.state() == StructuredTaskScope.Subtask.State.SUCCESS) {
                System.out.println(t2.get());
            }
            System.out.println("任务三状态：" + t3.state());
            if (t3.state() == StructuredTaskScope.Subtask.State.SUCCESS) {
                System.out.println(t3.get());
            }


        } catch (InterruptedException e) {
            System.out.println(e.getMessage());
        }
    }

    //只要有一个任务成功，就自动退出且关闭，其他任务都没有必要运行了
    private static void shutDownOnSuccesss() {

        try (var scope = new StructuredTaskScope.ShutdownOnSuccess()) {
            var t1 = scope.fork(MyAsyncTask.task1);
            var t2 = scope.fork(MyAsyncTask.task2);
            var t3 = scope.fork(MyAsyncTask.task3);
            scope.join();
            System.out.println("任务一状态：" + t1.state());
            if (t1.state() == StructuredTaskScope.Subtask.State.SUCCESS) {
                System.out.println(t1.get());
            }
            System.out.println("任务二状态：" + t2.state());
            if (t2.state() == StructuredTaskScope.Subtask.State.SUCCESS) {
                System.out.println(t2.get());
            }

            System.out.println("任务三状态：" + t3.state());
            if (t3.state() == StructuredTaskScope.Subtask.State.SUCCESS) {
                System.out.println(t3.get());
            }
        } catch (InterruptedException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    //只要有一个任务失败，就自动退出且关闭，其他任务都没有必要进行了
    private static void shutDownOnFailure() {
        try (var scope = new StructuredTaskScope.ShutdownOnFailure()) {

            var t1 = scope.fork(MyAsyncTask.task1);
            var t2 = scope.fork(MyAsyncTask.task2);
            var t3 = scope.fork(MyAsyncTask.failureTask);

            scope.join();

            System.out.println("任务一状态：" + t1.state());
            if (t1.state() == StructuredTaskScope.Subtask.State.SUCCESS) {
                System.out.println(t1.get());
            }
            System.out.println("任务二状态：" + t2.state());
            if (t2.state() == StructuredTaskScope.Subtask.State.SUCCESS) {
                System.out.println(t2.get());
            }

            System.out.println("任务三状态：" + t3.state());
            if (t3.state() == StructuredTaskScope.Subtask.State.SUCCESS) {
                System.out.println(t3.get());
            } else {
                System.out.println(t3.exception());
            }


        } catch (InterruptedException e) {
            System.out.println(e.getMessage());
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }
}
