package com.jinxuliang;

public class UseCustomScope {
    public static void main(String[] args) {
//        allSuccess();
        someFailure();
    }

    private static void allSuccess() {
        try (var scope = new CustomScope()) {
            var t1 = scope.fork(MyAsyncTask.task1);
            var t2 = scope.fork(MyAsyncTask.task2);
            var t3 = scope.fork(MyAsyncTask.task3);
            scope.join();
            if (scope.isHasFailure()) {
                System.out.println("出错了");
                scope.getExceptions().forEach(System.err::println);
            } else {
                System.out.println("程序运行的结果为：");
                scope.getTaskResults().forEach(System.err::println);
            }
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    private static void someFailure() {
        try (var scope = new CustomScope()) {
            scope.fork(MyAsyncTask.task1);
            scope.fork(MyAsyncTask.failureTask);
            scope.fork(MyAsyncTask.task3);
            scope.join();
            if (scope.isHasFailure()) {
                System.out.println("出错了");
                scope.getExceptions().forEach(System.err::println);
            } else {
                System.out.println("程序运行的结果为：");
                scope.getTaskResults().forEach(System.err::println);
            }
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }
}
