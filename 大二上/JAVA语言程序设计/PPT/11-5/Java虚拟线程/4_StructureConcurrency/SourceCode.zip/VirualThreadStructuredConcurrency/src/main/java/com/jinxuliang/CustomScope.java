package com.jinxuliang;

import java.util.Collection;
import java.util.List;
import java.util.concurrent.ConcurrentLinkedDeque;
import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.StructuredTaskScope;

//自定义StructuredTaskScope
public class CustomScope extends StructuredTaskScope<String> {
    //存储异步任务的结果
    private volatile Collection<String> taskResults = new ConcurrentLinkedDeque<>();
    public List<String> getTaskResults() {
        return taskResults.stream().toList();
    }
    //存储异步任务可能发生的异常
    private volatile Collection<Throwable> exceptions = new ConcurrentLinkedQueue<>();
    public List<Throwable> getExceptions() {
        return exceptions.stream().toList();
    }
    //用于供外界查询是否有失败的任务
    private volatile boolean hasFailure = false;
    public boolean isHasFailure() {
        return hasFailure;
    }
    public void setHasFailure(boolean hasFailure) {
        this.hasFailure = hasFailure;
    }

    @Override
    protected void handleComplete(Subtask<? extends String> subtask) {

        switch (subtask.state()) {
            case UNAVAILABLE -> {
                hasFailure = true;
                this.exceptions.add(new IllegalStateException("异步任务无法执行"));
            }
            case SUCCESS -> this.taskResults.add(subtask.get());
            case FAILED -> {
                hasFailure = true;
                this.exceptions.add(subtask.exception());
            }
        }
    }
}

