package com.jinxuliang;

import java.time.Duration;
import java.time.temporal.ChronoUnit;
import java.util.Random;
import java.util.concurrent.Callable;

public class MyAsyncTask {

    private static Random random = new Random();

    //用于模拟"成功的"异步任务
    public static String processSuccessAsyncTask(String taskInfo, int origin, int bound) {
        int randomTime = random.nextInt(origin, bound);
        sleepFor(randomTime, ChronoUnit.MILLIS);
        return "[" + taskInfo + "]运行结束，" + Thread.currentThread() + " 耗时：" + randomTime + "ms";
    }

    //用于模拟"失败的"异步任务
    public static String processFailureAsyncTask(String taskInfo, int origin, int bound) {
        int randomTime = random.nextInt(origin, bound);
        sleepFor(randomTime, ChronoUnit.MILLIS);
        throw new RuntimeException("[" + taskInfo + "]运行过程中抛出了异常");
    }

    //休眠指定的时间
    private static void sleepFor(int amount, ChronoUnit unit) {
        try {
            Thread.sleep(Duration.of(amount, unit));
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    public static Callable<String> task1 = () ->
            MyAsyncTask.processSuccessAsyncTask("异步任务一", 60, 150);
    public static Callable<String> task2 = () ->
            MyAsyncTask.processSuccessAsyncTask("异步任务二", 80, 100);
    public static Callable<String> task3 = () ->
            MyAsyncTask.processSuccessAsyncTask("异步任务三", 300, 1100);

    public static Callable<String> failureTask = () ->
            MyAsyncTask.processFailureAsyncTask("出错的异步任务", 10, 100);

}
