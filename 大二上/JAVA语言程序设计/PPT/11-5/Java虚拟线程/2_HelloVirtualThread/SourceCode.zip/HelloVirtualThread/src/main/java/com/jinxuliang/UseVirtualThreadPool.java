package com.jinxuliang;

import java.util.Scanner;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Executors;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class UseVirtualThreadPool {
      public static void main(String[] args) throws InterruptedException {
        //创建两个Map，里面放置虚拟线程和平台线程的名字
        var virtualThreads = ConcurrentHashMap.<String>newKeySet();
        var platformThreads = ConcurrentHashMap.<String>newKeySet();
        //线程函数
        Runnable task = () -> {
            //输出一个小点，表示线程正在工作
            System.out.print(".");
            Thread currentThread = Thread.currentThread();
            virtualThreads.add(currentThread.toString());
            //使用正则表达式，按照名字提取出线程池中的平台线程名
            Pattern WORKER_PATTERN = Pattern.compile("worker-[\\d?]+");
            Matcher pThreadMatcher = WORKER_PATTERN.matcher(currentThread.toString());
            if (pThreadMatcher.find()) {
                //抽取出负责执行的平台线程名称，加入到ConcurrentHashMap中
                //如果尝试加入同名的字符串，后来加入的会取代新加入的
                platformThreads.add(pThreadMatcher.group());
            }
        };
        //设定要执行20个工作任务
        int N_TASKS = 20;
        //每个工作任务，创建一个虚拟线程
        try (var executorService = Executors.newVirtualThreadPerTaskExecutor()) {
            for (int index = 0; index < N_TASKS; index++) {
                executorService.submit(task);
            }
        }
        System.out.println("\n敲回车看结果。");
        new Scanner(System.in).nextLine();
        System.out.println("# 虚拟线程数：" + virtualThreads.size());
        System.out.println("# 平台线程数:" + platformThreads.size());
        System.out.println("\n------虚拟线程列表---------");
        virtualThreads.forEach(System.out::println);
        System.out.println("\n-------平台线程列表--------");
        platformThreads.forEach(System.out::println);


    }

}
