package com.jinxuliang;

public class CreatingVirtualThreads {
    public static void main(String[] args) throws InterruptedException {
        //线程函数
        Runnable task = () -> {
            System.out.println("------------------");
            System.out.println("当前运行线程： " +
                    Thread.currentThread().getName() +
                    ",线程id:" + Thread.currentThread().threadId());
            System.out.println("是否背景线程？ " +
                    Thread.currentThread().isDaemon());
        };

        //普通线程，等价于：
        // Thread.ofPlatform().unstarted(task);
        Thread thread1 = new Thread(task);
        thread1.start();
        thread1.join();
        //平台线程
        Thread thread2 = Thread.ofPlatform()
                .daemon()
                .unstarted(task);
        thread2.start();
        thread2.join();

        //创建一个未启动的虚拟线程
        Thread thread3 = Thread.ofVirtual()
                .name("虚拟线程")
                .unstarted(task);
        //启动虚拟线程
        thread3.start();
        thread3.join();

        //创建一个虚拟线程并立即启动，未指定线程名字，名字为空。
        Thread thread4 = Thread.startVirtualThread(task);
        thread4.join();
    }
}
