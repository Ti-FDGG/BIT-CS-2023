package com.jinxuliang;

import java.util.Date;
import java.util.Locale;
import java.util.concurrent.Callable;
import java.util.concurrent.StructuredTaskScope;


public class Main {
    public static void main(String[] args) throws Exception {
//        whatIsScopedValue();
//        rebinding();
        scopedValueAndStructuredTaskScope();


    }

    //重绑定
    private static void rebinding() throws Exception {
        ScopedValue<String> scopedValue = ScopedValue.newInstance();
        //给其绑定一个初始值
        var result = ScopedValue.callWhere(scopedValue, new Date().toString(),
                () -> scopedValue.get().toString().toUpperCase());
        System.out.println(result);
        //重新绑定一个新值
        ScopedValue.runWhere(scopedValue, "abcd", () -> {
            System.out.println(scopedValue.get());
        });
    }

    private static void scopedValueAndStructuredTaskScope() {
        ScopedValue<String> scopedValue = ScopedValue.newInstance();
        //定义一个异步任务
        Callable<String> task = () -> {
            if (scopedValue.isBound()) {
                return scopedValue.get();
            } else {
                System.out.println("ScopedValue未绑定值");
                return "Unbound";
            }
        };
        //在虚拟线程中访问ScopeValue
        ScopedValue.where(scopedValue, "1234")
                .run(() -> {
                    try (var scope = new StructuredTaskScope<String>()) {
                        var t1 = scope.fork(task);
                        var t2 = scope.fork(() -> "异步任务中访问到的ScopedValue=" + scopedValue.get());
                        scope.join();
                        System.out.println(t1.get());
                        System.out.println(t2.get());
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                });
    }

    private static void whatIsScopedValue() {
        ScopedValue<String> scopedValue = ScopedValue.newInstance();
        //以下代码给ScopedValue赋值，并将与一个Lambda表达式绑定，从而将其作用域限定为此方法
        ScopedValue.where(scopedValue, "值存储于：" + new Date())
                .run(() -> {
                    System.out.println("ScopedValue是否被绑定？" + scopedValue.isBound());
                    //从绑定的ScopedValue中提取值
                    System.out.println(scopedValue.get());
                });
        System.out.println("ScopedValue是否被绑定？" + scopedValue.isBound());
        //尝试从未绑定的ScopedValue中提取值，会抛出NoSuchElementException
        System.out.println(scopedValue.get());
    }
}