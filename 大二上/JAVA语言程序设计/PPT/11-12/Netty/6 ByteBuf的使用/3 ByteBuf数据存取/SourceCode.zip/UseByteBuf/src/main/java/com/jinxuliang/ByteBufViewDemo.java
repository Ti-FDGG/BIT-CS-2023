package com.jinxuliang;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufUtil;
import io.netty.buffer.Unpooled;

public class ByteBufViewDemo {
    public static void main(String[] args) {
        var byteBuf = Unpooled.buffer();
        byte[] data = {11, 12, 13, 14};
        byteBuf.writeBytes(data);
        //原始数据：11,12,13,14,
        printByteBuf(byteBuf);
        System.out.println(ByteBufUtil.prettyHexDump(byteBuf));

        //创建一个新视图，不会复制原先ByteBuf的readerIndex和writerIndex
        var duplicate = byteBuf.duplicate();
        //输出与前一样：11,12,13,14,
        printByteBuf(byteBuf);
        //输出新视图内容，与前一样
        System.out.println(ByteBufUtil.prettyHexDump(duplicate));

        //修改第一个元素内容
        byteBuf.setByte(0, (byte) 100);
        //查看视图中的数据：100,12,13,14,
        printByteBuf(duplicate);
        System.out.println(ByteBufUtil.prettyHexDump(duplicate));

    }

    //打印ByteBuf中的内容
    public static void printByteBuf(ByteBuf byteBuf) {
        var count = byteBuf.readableBytes();
        for (int i = 0; i < count; i++) {
            System.out.print(byteBuf.getByte(i) + ",");
        }
        System.out.println();
    }
}
