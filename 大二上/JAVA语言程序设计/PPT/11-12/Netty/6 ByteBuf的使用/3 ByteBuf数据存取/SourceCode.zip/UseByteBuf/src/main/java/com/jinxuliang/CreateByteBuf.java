package com.jinxuliang;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufAllocator;
import io.netty.buffer.PooledByteBufAllocator;
import io.netty.buffer.UnpooledByteBufAllocator;

public class CreateByteBuf {
    public static void main(String[] args) {
        //看看默认的分配器是哪个？
        //PooledByteBufAllocator(directByDefault: true)
        System.out.println(ByteBufAllocator.DEFAULT);

        ByteBuf buffer = null;

        //方法1：通过默认分配器分配　　　　　
        //初始容量为9、最大容量为100的缓冲区
        buffer = ByteBufAllocator.DEFAULT.buffer(9, 100);
        //PooledUnsafeDirectByteBuf(ridx: 0, widx: 0, cap: 9/100)
        System.out.println(buffer);

        //方法2：通过默认分配器分配　　　　　
        //初始容量为256、最大容量为Integer.MAX_VALUE的缓冲区
        buffer = ByteBufAllocator.DEFAULT.buffer();
        //PooledUnsafeDirectByteBuf(ridx: 0, widx: 0, cap: 256)
        System.out.println(buffer);

        //方法3：非池化分配器，分配Java的堆（Heap）结构内存缓冲区
        buffer = UnpooledByteBufAllocator.DEFAULT.heapBuffer();
        //UnpooledByteBufAllocator$InstrumentedUnpooledUnsafeHeapByteBuf(ridx: 0, widx: 0, cap: 256)
        System.out.println(buffer);

        //方法4：池化分配器，分配由操作系统管理的直接内存缓冲区
        buffer = PooledByteBufAllocator.DEFAULT.directBuffer();
        //PooledUnsafeDirectByteBuf(ridx: 0, widx: 0, cap: 256)
        System.out.println(buffer);
    }
}
