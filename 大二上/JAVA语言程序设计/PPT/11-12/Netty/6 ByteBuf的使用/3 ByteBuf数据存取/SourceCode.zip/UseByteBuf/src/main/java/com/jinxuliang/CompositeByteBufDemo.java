package com.jinxuliang;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.CompositeByteBuf;
import io.netty.buffer.Unpooled;

import java.nio.charset.StandardCharsets;

public class CompositeByteBufDemo {
    public static void main(String[] args) {

        //准备header部分
        byte[] headerValue = """
                content-type: text/html; charset=utf-8;
                Status Code: 200 OK;
                
                """.getBytes(StandardCharsets.UTF_8);
        ByteBuf header = Unpooled.wrappedBuffer(headerValue);

        //准备body部分
        byte[] bodyValue = """
                <html>
                <head>
                    <meta charset="utf-8" />
                    <title>hello</title>
                </head>
                <body>
                <h1>hello</h1>
                </body>
                """.getBytes(StandardCharsets.UTF_8);
        ByteBuf body = Unpooled.wrappedBuffer(bodyValue);

        //构建CompositeByteBuf
        CompositeByteBuf httpBuf = Unpooled.compositeBuffer();
        //追加ByteBuf到CompositeByteBuf中
        httpBuf.addComponents(header, body);

        //对比三个字节缓冲区
        //输出：UnpooledHeapByteBuf(ridx: 0, widx: 62, cap: 62/62)
        System.out.println(header);
        //输出：UnpooledHeapByteBuf(ridx: 0, widx: 106, cap: 106/106)
        System.out.println(body);
        //输出：CompositeByteBuf(ridx: 0, widx: 0, cap: 168, components=2)
        System.out.println(httpBuf);

        System.out.println(httpBuf.readableBytes());


        //读取第一个ByteBuf的内容
        var readHeaderValue = httpBuf.component(0)
                .toString(StandardCharsets.UTF_8);
        System.out.println(readHeaderValue);
        //读取第二个ByteBuf的内容
        var readBodyValue = httpBuf.component(1)
                .toString(StandardCharsets.UTF_8);
        System.out.println(readBodyValue);
        //减少CompositeByteBuf引用计数，为0时被回收
        httpBuf.release();

    }
}
