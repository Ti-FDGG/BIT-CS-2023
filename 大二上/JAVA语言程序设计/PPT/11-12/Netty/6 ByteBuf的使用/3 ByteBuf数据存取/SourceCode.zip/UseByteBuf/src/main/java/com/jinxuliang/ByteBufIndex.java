package com.jinxuliang;

import io.netty.buffer.Unpooled;

public class ByteBufIndex {
    public static void main(String[] args) {
        var byteBuf = Unpooled.buffer(10);
        //UnpooledByteBufAllocator$InstrumentedUnpooledUnsafeHeapByteBuf(ridx: 0, widx: 0, cap: 10)
        //初始值：readerIndex=writerIndex=0
        System.out.println(byteBuf);

        //写入8个字节
        for (int i = 0; i < 8; i++) {
            byteBuf.writeByte(i);
        }
        //UnpooledByteBufAllocator$InstrumentedUnpooledUnsafeHeapByteBuf(ridx: 0, widx: 8, cap: 10)
        //readerIndex不变，writerIndex=8
        System.out.println(byteBuf);

        //使用get操作读取5个字节
        for (int i = 0; i < 5; i++) {
            //get操作，不会改变读索引
            System.out.println(byteBuf.getByte(i));
        }
        //UnpooledByteBufAllocator$InstrumentedUnpooledUnsafeHeapByteBuf(ridx: 0, widx: 8, cap: 10)
        //readerIndex=0
        System.out.println(byteBuf);
        //使用read操作读取5个字节
        for (int i = 0; i < 5; i++) {
            //read操作，会改变读索引
            System.out.println(byteBuf.readByte());
        }
        //UnpooledByteBufAllocator$InstrumentedUnpooledUnsafeHeapByteBuf(ridx: 5, widx: 8, cap: 10)
        //readerIndex=5
        System.out.println(byteBuf);

        //接着上面已写入的8字节数据，再写入5个字节，很明显，这时，超过了原先设定的10个字节的容量
        for (int i = 0; i < 5; i++) {
            byteBuf.writeByte(8+i);
        }
        //UnpooledByteBufAllocator$InstrumentedUnpooledUnsafeHeapByteBuf(ridx: 5, widx: 13, cap: 64)
        //容量从原先的10，一下子跳到了64，读与写索引不变
        System.out.println(byteBuf);

        //丢弃已经读过的数据
        byteBuf.discardReadBytes();
        //UnpooledByteBufAllocator$InstrumentedUnpooledUnsafeHeapByteBuf(ridx: 0, widx: 8, cap: 64)
        //由于前5个已经被读过的数据被丢弃，现在，读写索引均有改变，值减少了5
        //readerIndex原先为5，现在变成了0
        //writerIndex原先为13,现在变成了8
        System.out.println(byteBuf);
    }
}
