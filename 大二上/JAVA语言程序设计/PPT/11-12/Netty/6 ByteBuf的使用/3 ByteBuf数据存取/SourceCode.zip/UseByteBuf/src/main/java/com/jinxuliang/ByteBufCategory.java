package com.jinxuliang;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufUtil;
import io.netty.buffer.Unpooled;

import java.util.Arrays;

public class ByteBufCategory {
    public static void main(String[] args) {
//        useHeapByteBuf();

        useDirectByteBuf();
    }
    //展示直接缓冲区的基本用法
    private static void useDirectByteBuf() {
        ByteBuf directBuf = Unpooled.directBuffer(10);
        //输出：false
        System.out.println(directBuf.hasArray());
        //写入6个字节
        for (int i = 0; i < 6; i++) {
            directBuf.writeByte(i);
        }
        //输出：readerIndex 0
        System.out.println("readerIndex " + directBuf.readerIndex());
        //输出：writerIndex 6
        System.out.println("writerIndex " + directBuf.writerIndex());
        //输出：readableBytes 6
        System.out.println("readableBytes " + directBuf.readableBytes());
        //从readIndex开始，读取所有可读内容，放到字节数组中：
        byte[] readableBytes = ByteBufUtil.getBytes(directBuf);
        //输出：[0, 1, 2, 3, 4, 5]
        System.out.println(Arrays.toString(readableBytes));
    }

    //展示堆缓冲区的基本用法
    private static void useHeapByteBuf() {
        ByteBuf heapBuf = Unpooled.buffer(10);
        //写入6个字节
        for (int i = 0; i < 6; i++) {
            heapBuf.writeByte(i);
        }
        //输出：true
        System.out.println(heapBuf.hasArray());
        //获取内部支撑数组的引用
        byte[] array = heapBuf.array();
        //输出支撑数组的内容
        System.out.println(Arrays.toString(array));
        //可以直接修改数组的内容：[0, 1, 2, 3, 4, 5, 0, 0, 0, 0]
        array[1] = 100;
        //输出支撑数组的内容：[0, 100, 2, 3, 4, 5, 0, 0, 0, 0]
        System.out.println(Arrays.toString(array));
        //查询ByteBuf的内容
        //         |  0  1  2  3  4  5  6  7  8  9  a  b  c  d  e  f |
        //+--------+-------------------------------------------------+----------------+
        //|00000000| 00 64 02 03 04 05                               |.d....          |
        //+--------+-------------------------------------------------+----------------+
        System.out.println(ByteBufUtil.prettyHexDump(heapBuf));
        //查询读写指针位置
        //输出：readerIndex 0
        System.out.println("readerIndex " + heapBuf.readerIndex());
        //输出：writerIndex 6
        System.out.println("writerIndex " + heapBuf.writerIndex());
        //输出：readableBytes 6
        System.out.println("readableBytes " + heapBuf.readableBytes());
    }
}
