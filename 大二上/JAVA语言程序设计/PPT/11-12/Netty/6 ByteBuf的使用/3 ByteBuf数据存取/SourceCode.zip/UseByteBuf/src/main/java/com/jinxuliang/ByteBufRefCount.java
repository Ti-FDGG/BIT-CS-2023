package com.jinxuliang;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.ByteBufAllocator;

public class ByteBufRefCount {
    public static void main(String[] args) {
        ByteBuf buf = ByteBufAllocator.DEFAULT.buffer();
        //初始计数值：1
        System.out.println("初始计数值：" + buf.refCnt());
        buf.retain();
        //retain()之后，计数值：2
        System.out.println("retain()之后，计数值：" + buf.refCnt());
        buf.release();
        //release()之后，计数值：1
        System.out.println("release()之后，计数值：" + buf.refCnt());
        //写入一个数据,一切正常
        buf.writeByte(100);
        buf.release();
        //再次release()之后，计数值：0
        System.out.println("再次release()之后，计数值：" + buf.refCnt());
        //再次写入一个数据，抛出IllegalReferenceCountException
        buf.writeByte(100);
    }
}
