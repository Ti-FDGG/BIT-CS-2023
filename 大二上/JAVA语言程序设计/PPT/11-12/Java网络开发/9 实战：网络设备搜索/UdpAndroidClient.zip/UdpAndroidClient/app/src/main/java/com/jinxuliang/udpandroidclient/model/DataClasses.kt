package com.jinxuliang.udpandroidclient.model

//接收到的广播信息
data class BroadcastInfo (val deviceCenterIp:String,
                          val deviceCenterListenPort:Int)

//本手机设备的信息
data class DeviceInfo(
    val ip:String,
    val port:Int,
    val info:String
)

//手机App的IP地址
data class IpInfo(
    val name: String,
    val ip: String
)

