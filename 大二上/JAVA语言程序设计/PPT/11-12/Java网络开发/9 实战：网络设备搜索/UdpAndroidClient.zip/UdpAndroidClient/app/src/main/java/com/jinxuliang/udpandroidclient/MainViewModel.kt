package com.jinxuliang.udpandroidclient

import androidx.compose.runtime.MutableState
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.gson.Gson
import com.jinxuliang.udpandroidclient.model.BroadcastInfo
import com.jinxuliang.udpandroidclient.model.CLIENT_ID
import com.jinxuliang.udpandroidclient.model.DEVICE_LISTEN_PORT
import com.jinxuliang.udpandroidclient.model.DeviceInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.net.DatagramSocket

class MainViewModel : ViewModel() {
    //供UI绑定
    private val _info = mutableStateOf("");
    val info: State<String>
        get() = _info

    //等待接收消息
    fun waitForReceiveMessage() {
        viewModelScope.launch(Dispatchers.IO) {
            _info.value = "UDP客户端:$CLIENT_ID 在端口 $DEVICE_LISTEN_PORT 监听"
            val ip = getLocalIpAddress()!!
            while (true) {
                val ds = DatagramSocket(DEVICE_LISTEN_PORT).use {
                    val msg = receiveMessage(it)
                    val broadcastInfo = Gson().fromJson(msg, BroadcastInfo::class.java)
                    //取回数据
                    _info.value = broadcastInfo.toString()
                    //回发数据
                    val deviceInfo = DeviceInfo(ip, DEVICE_LISTEN_PORT, "手机："+CLIENT_ID)
                    val json = Gson().toJson(deviceInfo)
                    sendMessageTo(
                        json, broadcastInfo.deviceCenterIp, broadcastInfo.deviceCenterListenPort
                    )
                    _info.value = "本机信息己经发送到设备控制中心。"
                }
                //等5秒再更新
                delay(5000)
            }
        }
    }

    fun showIPInfo() {
        viewModelScope.launch(Dispatchers.Default) {
            _info.value = getLocalIpAddress()!!
        }
    }
}