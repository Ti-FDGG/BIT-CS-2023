package com.jinxuliang.udpandroidclient

import android.util.Log
import com.jinxuliang.udpandroidclient.model.IpInfo
import java.io.IOException
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.Inet4Address
import java.net.InetAddress
import java.net.NetworkInterface
import java.net.SocketException
import java.nio.charset.StandardCharsets

//使用UDP发送消息
fun sendMessageTo(
    message: String, destinationIP: String,
    destinationPort: Int
) {
    val messageData = message.toByteArray(StandardCharsets.UTF_8)
    val address = InetAddress.getByName(destinationIP)
    val sendPacket = DatagramPacket(
        messageData, messageData.size, address,
        destinationPort
    )
    DatagramSocket().use { datagramSocket ->
        datagramSocket.send(sendPacket)
    }
}

//从DatagramSocket中接收信息，以字符串方式返回收到的信息
fun receiveMessage(ds: DatagramSocket): String? {
    val dataBuffer = ByteArray(1024)
    val receivePack = DatagramPacket(dataBuffer, dataBuffer.size)
    //在此阻塞等待接收
    ds.receive(receivePack)
    val ip = receivePack.address.hostAddress
    val port = receivePack.port // 发送者的端口
    val dataLen = receivePack.length //获取接收到的数据长度
    //转换为字符串
    val message = String(receivePack.data,0, length = dataLen)
    println("\n收到外部发来的信息：$message")
    print("外部数据包的")
    println("ip:$ip\tport:$port")
    return message
}

//获取本手机的IP地址
fun getLocalIpAddress(): String? {
    try {
        val en = NetworkInterface.getNetworkInterfaces()
        while (en.hasMoreElements()) {
            val intf: NetworkInterface = en.nextElement()
            val enumIpAddr = intf.getInetAddresses()
            while (enumIpAddr.hasMoreElements()) {
                val inetAddress: InetAddress = enumIpAddr.nextElement()
                if (!inetAddress.isLoopbackAddress && inetAddress is Inet4Address) {
                    return inetAddress.hostAddress
                }
            }
        }
    } catch (ex: SocketException) {
        Log.d("IP", ex.message!!)
    }
    return null
}