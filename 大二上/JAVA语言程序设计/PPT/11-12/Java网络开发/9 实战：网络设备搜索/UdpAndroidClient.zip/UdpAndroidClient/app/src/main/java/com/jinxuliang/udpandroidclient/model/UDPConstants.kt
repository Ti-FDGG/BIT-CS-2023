package com.jinxuliang.udpandroidclient.model

import java.util.UUID

//本手机UDP监听端口
const val DEVICE_LISTEN_PORT = 20000
//本手机设备标识
val CLIENT_ID = UUID.randomUUID().toString()