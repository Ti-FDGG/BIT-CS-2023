@FunctionalInterface
public interface MyFunctionInterface {
    void process();
}

