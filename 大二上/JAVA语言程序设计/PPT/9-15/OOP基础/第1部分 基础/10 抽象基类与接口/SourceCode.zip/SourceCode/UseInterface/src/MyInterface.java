public interface MyInterface {
    //JDK 9: 接口中可以定义私有成员，它可以被接口的默认方法调用
    private void secret() {
        System.out.println("Secret Method defined in interface");
    }
    //接口的默认方法
    default void defaultMethod(){
        secret();
        System.out.println("defaultMethod()");
    }
    void func();
}

