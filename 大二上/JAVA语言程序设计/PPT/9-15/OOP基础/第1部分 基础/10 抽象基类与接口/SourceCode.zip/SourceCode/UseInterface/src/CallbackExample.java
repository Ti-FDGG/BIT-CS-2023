import java.util.Arrays;
import java.util.Comparator;

public class CallbackExample {
    public static void main(String[] args) {
        String[] friends={"Mary","John","Li","Peter"};
        //sort方法内部会回调LengthCompartor的compare方法
        Arrays.sort(friends,new LengthComparator());
        //输出按字符串长度排序的结果：
        //Li,Mary,John,Peter,
        for(var friend:friends){
            System.out.print(friend+",");
        }
    }
}

//按字符串长度决定两个字符串“谁大谁小”
class LengthComparator implements Comparator<String>{
    @Override
    public int compare(String first, String second) {
        return first.length()-second.length();
    }
}
