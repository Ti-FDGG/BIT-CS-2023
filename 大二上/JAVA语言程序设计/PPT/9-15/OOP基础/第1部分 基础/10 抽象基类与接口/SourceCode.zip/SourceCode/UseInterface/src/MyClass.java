public class MyClass implements MyInterface {
    @Override
    public void func() {
        System.out.println("MyClass.func()");
    }

    public static void main(String[] args) {
        MyInterface obj = new MyClass();
        obj.defaultMethod();
        obj.func();
    }
}

