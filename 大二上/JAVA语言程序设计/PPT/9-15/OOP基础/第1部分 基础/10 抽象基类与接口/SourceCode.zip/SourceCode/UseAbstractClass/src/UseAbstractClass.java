public class UseAbstractClass {

    public static void main(String[] args) {
        Pet d = new Dog();
        //汪汪汪~~~
        d.speak();
        //喵喵喵~~~
        Pet c = new Cat();
        c.speak();
    }
}

abstract class Pet {
    abstract void speak();
}

class Dog extends Pet {

    @Override
    void speak() {
        System.out.println("汪汪汪~~~");
    }
}

class Cat extends Pet {

    @Override
    void speak() {
        System.out.println("喵喵喵~~~");
    }
}
