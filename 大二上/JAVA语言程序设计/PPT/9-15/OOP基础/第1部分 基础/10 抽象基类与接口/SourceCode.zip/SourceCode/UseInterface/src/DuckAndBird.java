import java.time.Duration;
import java.util.function.BiFunction;

public class DuckAndBird {
    public static void main(String[] args) {
        Duck duck = new Duck();
        duck.fly();
        //Duck对象实现了IFood和ISwim接口，
        //所以可以赋值给相应的变量
        IFood food = duck;
        food.cook();
        ISwim swimAnimal = duck;
        swimAnimal.swim();
    }
}

//所有食物应该实现这个接口
interface IFood {
    void cook();
}
//所有的水鸟，应该实现此接口
interface ISwim {
    void swim();
}

abstract class Bird {
    //鸟有翅膀，会飞！
    abstract void fly();
}
//鸭子是一种水鸟，也是一种食物
class Duck extends Bird
        implements ISwim, IFood {

    @Override
    public void cook() {
        System.out.println("我不想成为烤鸭!");
    }

    @Override
    public void swim() {
        System.out.println("我能游泳！");
    }

    @Override
    void fly() {
        System.out.println("我会飞！");
    }
}

