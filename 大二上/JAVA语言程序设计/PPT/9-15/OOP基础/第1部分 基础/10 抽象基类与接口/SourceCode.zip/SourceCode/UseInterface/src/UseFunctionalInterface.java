import java.time.LocalDate;

public class UseFunctionalInterface {
    public static void main(String[] args) {
        MyFunctionInterface obj = () -> {
            var info = """
                    工作完成于：%s
                    """.formatted(LocalDate.now());
            System.out.println(info);
        };
        obj.process();
    }
}

