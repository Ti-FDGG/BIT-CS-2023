import java.util.Arrays;

public class InitArray {
    public static void main(String[] args) {
        //声明数据变量并分配内存，同时初始化数组元素
        int[] n = {32, 27, 64, 18, 95, 14};

        var output = new StringBuilder("下标\t值\n");
        //使用StrinBuilder循环构建输出字符串
        for (int i = 0; i < n.length; i++)
            output.append(i + "\t" + n[i] + "\n");
        System.out.println(output);

        //另一种初始化方式
        int[] arr = new int[5];
        //使用固定值填充
        Arrays.fill(arr, 1);
        //连接所有元素，构成一个字符串
        String arrContent = Arrays.toString(arr);
        //输出：[1, 1, 1, 1, 1]
        System.out.println(arrContent);

    }
}

