public class ForEachIsReadOnly {
    public static void main(String[] args) {
        int[] arr={1,2,3,4,5};
        System.out.println("foreach之前：");
        printArray(arr);
        //在foreach循环中修改数值
        for(int value : arr){
            value *=2;
        }
        System.out.println("\nforeach之后：");
        printArray(arr);
    }
    //此方法将数组的内容转换为字符串，然后输出
    static void printArray(int[] arr) {
        for (int i = 0; i < arr.length; i++) {
            if (i != arr.length - 1) {
                System.out.print(arr[i] + ",");
            } else
                System.out.print(arr[i]);
        }
    }
}

