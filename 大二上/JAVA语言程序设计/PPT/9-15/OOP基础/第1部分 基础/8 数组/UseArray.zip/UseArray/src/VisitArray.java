public class VisitArray {
    public static void main(String[] args) {

        int[] arr = new int[10];
        //使用传统的for循环访问数组
        for (int i = 0; i < arr.length; i++)
            arr[i] = i;

        //使用foreach循环访问数组
        for (var value : arr) {
            System.out.print(value + ",");
        }



    }
}
