package exercise;

public class NullPointerArrayExample {


    public static void main(String[] args) {
        MyClass[] arr = new MyClass[10];
        arr[2].value = 100;

    }

}

class MyClass {
    public int value = 1;
}
