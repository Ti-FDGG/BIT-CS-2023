import java.util.Arrays;

public class ArrayAsArgument {

    public static void main(String[] args) {
        int[] oneArr = {1, 2, 3, 4};
        System.out.println("Before:" + Arrays.toString(oneArr));
        //Before:[1, 2, 3, 4]
        processArr(oneArr);
        //After:[2, 2, 3, 4]
        System.out.println("After:" + Arrays.toString(oneArr));
    }

    static void processArr(int[] arr) {
        arr[0] *= 2;
        int[] otherArr = {4, 5, 6};
        //让arr引用另外一个数组
        arr = otherArr;
    }
}
