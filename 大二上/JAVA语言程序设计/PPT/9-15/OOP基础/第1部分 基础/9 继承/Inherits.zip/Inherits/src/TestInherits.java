
class Grandparent {

    public Grandparent() {
        System.out.println("GrandParent Created.");
    }

    public Grandparent(String string) {
        System.out.println("GrandParent Created.String:" + string);
    }
}

class Parent extends Grandparent {

    public Parent() {
		//请试着先后取消这两句的注释，看看会有什么事情发生
        //super("Hello.Grandparent.");
        System.out.println("Parent Created");
        //super("Hello.Grandparent.");
    }
}

class Child extends Parent {

    public Child() {
        System.out.println("Child Created");
    }
}

public class TestInherits {

    public static void main(String args[]) {
        Child c = new Child();
    }
}
