public class ShapeAndRectangle {
}

class Shape{
    private final int top;
    private final int left;
    //基类的构造方法
    public Shape(int top, int left) {
        this.top = top;
        this.left = left;
    }
}

class Rectangle extends Shape{
    private final int width;
    private final int height;

    public Rectangle(int width,int height){
        //调用本类的构造方法
        this(0,0,width,height);
    }

    public Rectangle(int top, int left,
                     int width, int height) {
        super(top, left); //调用父类的构造方法
        this.width = width;
        this.height = height;
    }
}
