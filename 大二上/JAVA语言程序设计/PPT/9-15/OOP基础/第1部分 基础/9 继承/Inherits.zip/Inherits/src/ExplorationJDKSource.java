
public class ExplorationJDKSource {
    public static void main(String[] args) {
        //输出：A@7ef20235
        System.out.println(new A());
    }
}

//类A没有定义任何的成员
class A {
}


