
public class UseSupper {
    public static void main(String[] args) {
        var user = new User("张三");
        System.out.println(user.getName() + "的折扣为：" + user.getDiscount());

        var vip = new VIPUser("李四", "黄金");
        System.out.println(vip.getName() + "是" + vip.getVipLevel()
                + "会员，享受的折扣为：" + vip.getDiscount());
    }
}

//某电商网站的用户打折信息
class User {
    private final String name;
    private final double discount;

    public User(String name) {
        //使用this调用私有构造函数，以便初始化折扣值为1.0
        this(name, 1.0);
    }

    //私有构造函数，仅供自己调用
    private User(String name, double discount) {
        this.name = name;
        this.discount = discount;
    }

    public String getName() {
        return name;
    }
    public double getDiscount() {
        return discount;
    }
}

//VIP用户也“是一种”普通用户
class VIPUser extends User {
    //VIP会员级别
    private String vipLevel = "白银";
    public VIPUser(String name, String vipLevel) {
        //使用super调用基类的构造方法
        super(name);
        this.vipLevel = vipLevel;
    }
    //VIP用户购买商品可以打折，因此此处重写基类的同名方法
    @Override
    public double getDiscount() {
        //使用super调用基类的同名方法
        var superDiscount = super.getDiscount();
        return switch (vipLevel) {
            case "白银" -> superDiscount * 0.8;
            case "黄金" -> superDiscount * 0.7;
            case "钻石" -> superDiscount * 0.6;
            default -> superDiscount;
        };
    }
    public String getVipLevel() {
        return vipLevel;
    }
}
