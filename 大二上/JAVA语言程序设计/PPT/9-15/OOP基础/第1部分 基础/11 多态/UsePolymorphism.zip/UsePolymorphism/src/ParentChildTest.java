
public class ParentChildTest {
    public static void main(String[] args) {
        var parent = new ParentClass();
        parent.printValue();
        var child = new ChildClass();
        child.printValue();

        parent = child;
        parent.printValue();

        parent.myValue++;
        parent.printValue();

        ((ChildClass) parent).myValue++;
        parent.printValue();
    }
}

class ParentClass {
    public int myValue = 100;

    public void printValue() {
        System.out.println("Parent.printValue(),myValue=" + myValue);
    }
}

class ChildClass extends ParentClass {
    public int myValue = 200;

    public void printValue() {
        System.out.println("Child.printValue(),myValue=" + myValue);
    }
}