

package cn.edu.bit.cs.utils;
/**
 * 此类封装一些字符串操作的功能
 */
public class MyStringUtil {
    // 方法功能：将一个字符串倒序输出
    public static String reverseString(String inputStr) {
        StringBuffer buff = new StringBuffer();

        for (int i = inputStr.length() - 1; i >= 0; i--)
            buff.append(inputStr.charAt(i));

        return buff.toString();
    }
}

