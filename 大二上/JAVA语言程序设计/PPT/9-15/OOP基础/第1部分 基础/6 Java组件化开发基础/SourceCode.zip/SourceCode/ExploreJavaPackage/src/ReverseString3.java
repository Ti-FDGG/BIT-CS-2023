

//导入另一个模块包中的类
import cn.edu.bit.cs.utils.MyStringUtil;

public class ReverseString3 {

    public static void main(String[] args) {
        String str="abcd";
        System.out.println(MyStringUtil.reverseString(str));
    }

}

