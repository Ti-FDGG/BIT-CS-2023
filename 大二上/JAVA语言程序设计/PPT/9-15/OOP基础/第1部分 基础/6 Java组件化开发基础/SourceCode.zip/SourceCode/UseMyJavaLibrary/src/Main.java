import cn.edu.bit.cs.utils.*;

public class Main {
    public static void main(String[] args) {
        var resversed =
                MyStringUtil.reverseString("abcd");
        System.out.println(resversed);
    }
}
