
public class ReverseString1 {

    // 示例程序功能：将一个字符串倒序输出
    public static void main(String[] args) {
        String str = "abcd";
        StringBuffer buff = new StringBuffer();
        for (int i = str.length() - 1; i >= 0; i--)
            buff.append(str.charAt(i));
        System.out.println(buff.toString());
    }

}

