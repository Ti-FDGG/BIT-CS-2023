

public class ReverseString2 {

	public static void main(String[] args) {
		String str = "abcd";
		System.out.println(reverseString(str));
	}

	// 方法功能：将一个字符串倒序输出
	private static String reverseString(String inputStr) {
		StringBuffer buff = new StringBuffer();

		for (int i = inputStr.length() - 1; i >= 0; i--)
			buff.append(inputStr.charAt(i));

		return buff.toString();
	}

}

