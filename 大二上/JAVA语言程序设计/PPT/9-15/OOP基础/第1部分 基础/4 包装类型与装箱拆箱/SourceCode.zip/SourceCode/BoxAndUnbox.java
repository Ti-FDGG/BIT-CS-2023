
public class BoxAndUnbox {
    public static void main(String[] args) {
        int value = 100;
        Integer obj = value;  //װ��
        int result = obj * 2;     //����
        System.out.println(result);
    }
}
