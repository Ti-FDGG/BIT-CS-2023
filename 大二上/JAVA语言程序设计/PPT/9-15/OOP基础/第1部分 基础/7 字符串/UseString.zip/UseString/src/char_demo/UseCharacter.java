package char_demo;

import javax.swing.*;
import java.util.Scanner;

public class UseCharacter {

   public static void main(String[] args)
   {
      //characterBasic();
      testGetCharInfo();
   }

   static void characterBasic() {
      //两种创建Character对象的方法
      Character c1 = 'A';
      Character c2 = Character.valueOf( 'a' );

      //使用charValue方法将Character对象转换为char类型
      //使用toString()方法将Character对象转换为字符串
      String output =
         "c1 = " + c1.charValue() +
         "\nc2 = " + c2.toString() +
         "\n\nhash code for c1 = " + c1.hashCode() +
         "\nhash code for c2 = " + c2.hashCode();
      //比较两个Character对象的内容是否相等
      if (  c1.equals( c2 ) )
         output += "\n\nc1 and c2 are equal";
      else
         output += "\n\nc1 and c2 are not equal";

      System.out.println(output);
   }

   static void testGetCharInfo() {
      var scanner = new Scanner(System.in);
      System.out.print("输入一个字符，之后敲回车键：");
      var userInput = scanner.nextLine();
      //移除前后的空格
      userInput = userInput.strip();
      //取出第一个字符
      String result = getCharInfo(userInput.charAt(0));
      System.out.println(result);
   }

   static String getCharInfo(char c) {
      String info =
              "是否在Unicode标准字符集中: " + Character.isDefined(c) +
                      "\n是否数字: " + Character.isDigit(c) +
                      "\n是否可作为Java标识符的第一个字符：" +
                      Character.isJavaIdentifierStart(c) +
                      "\n是否可作为Java标识符的其他字符: " +
                      Character.isJavaIdentifierPart(c) +
                      "\n是不是字母: " + Character.isLetter(c) +
                      "\n是字母或者数字: " +
                      Character.isLetterOrDigit(c) +
                      "\n是小写字母: " + Character.isLowerCase(c) +
                      "\n是大写字母: " + Character.isUpperCase(c) +
                      "\n转为大写: " + Character.toUpperCase(c) +
                      "\n转为小写: " + Character.toLowerCase(c);
      return info;
   }
}

