package string_token;

import java.util.Scanner;
import java.util.StringTokenizer;

public class UseStringTokenizer {
    public static void main(String[] args) {
        System.out.print("请输入一句英文语句：");
        var scanner = new Scanner(System.in);
        var userInput = scanner.nextLine();

        StringTokenizer tokens =
                new StringTokenizer(userInput);
        StringBuffer output = new StringBuffer();
        output.append("\nNumber of elements: " +
                tokens.countTokens() +
                "\nThe tokens are:\n");
        while (tokens.hasMoreTokens())
            output.append(tokens.nextToken() + "\n");

        System.out.println(output.toString());
    }
}

