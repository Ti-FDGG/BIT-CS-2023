package char_demo;

import java.util.Scanner;

public class UseChar {
    public static void main(String[] args) {
        charBasic();
        chineseChar();
        //testGetCharInfo();

    }

    static void charBasic() {
        char c1 = 'A';
        System.out.println(c1);
        //char变量可以赋值给int变量
        int charValue = c1;
        //int变量中保存的实际上是Unicdoe码值
        System.out.println(charValue);//65
        //可以直接把一个整数传给char变量，这个整数被当成Unicode码值
        char c2 = 65;
        System.out.println(c2); //A
        //可以直接使用==比较两个char变量的数值
        System.out.println(c1 == c2);//true
    }

    static void chineseChar() {
        char c1 = '中';
        System.out.println(c1);
        //char变量可以赋值给int变量
        int charValue = c1;
        //int变量中保存的实际上是汉字字符所对应的Unicode值
        System.out.println(charValue);//20013
        //可以直接把一个整数传给char变量，这个整数被当成Unicode码值
        char c2 = (char)charValue;
        System.out.println(c2); //中
        //可以直接使用==比较两个char变量的数值
        System.out.println(c1 == c2);//true
    }


}
