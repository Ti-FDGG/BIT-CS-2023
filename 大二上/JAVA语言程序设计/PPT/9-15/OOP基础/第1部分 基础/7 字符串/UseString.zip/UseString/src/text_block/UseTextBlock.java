package text_block;

//JDK 15
public class UseTextBlock {
    static int i = 0;

    public static void main(String[] args) {
       // printTextBlock();

        fillTextBlock("Hello", 1000);
    }

    private static void printTextBlock() {

        //使用连续三个双引号，定义一个多行文本块
        String poem = """
                        题临安邸
                       （宋）林升
                山外青山楼外楼，西湖歌舞几时休。
                暖风熏得游人醉，直把杭州作汴州。
                """;

        //输出整首诗歌
        System.out.println(poem.stripIndent());

        System.out.println("\n按照行输出：\n");
        //JDK11为String类添加了一个lines()方法，
        //此方法返回一个Stream<String>对象，
        //可以把它看成是一个行的集合，
        //这里用到了Lambda表达式将其按行输出
        //Lambda表达式中的用于生成行号的变量i
        //是类中定义的一个静态变量
        poem.lines().forEach(line -> {
            i++;
            System.out.println(i + " " + line);
        });
    }

    private static void fillTextBlock(String strValue, int intValue) {
        String textBlock = """
                    从外部传入的字符串参数值：%s,
                              int参数值：%d
                """;
        textBlock = textBlock.formatted(strValue, intValue);
        System.out.println(textBlock);
    }
}
