package string_demo;

import java.time.LocalDate;

public class UseString {
    public static void main(String[] args) {
        //stringConstructors();
        //stringAndArray();

        //stringRepeat();
        //stringConcat();

        //stringFill();

        //stringStrip();
        //stringIndent();

        //stringIsBlankOrEmpty();

        //stringPool();
        //stringAssign();

        //stringHashCode();
        //stringCompare();

        //stringIndex();
        //stringStartEnd();

        stringSlice();
    }

    //展示字符串的构造方法
    static void stringConstructors() {
        char charArray[] = {'b', 'i', 'r', 't', 'h', ' ',
                'd', 'a', 'y'};
        byte byteArray[] = {(byte) 'n', (byte) 'e', (byte) 'w',
                (byte) ' ', (byte) 'y', (byte) 'e',
                (byte) 'a', (byte) 'r'};

        String s, s1, s2, s3, s4, s5, s6, s7, s8, s9, output;

        s = new String("hello");
        //分配缓冲区
        var buffer = new StringBuffer("Welcome to Java Programming!");

        // 字符串对象的多种构造方法
        s1 = new String();    //缺省构造方法，可被简化为直接赋值空串
        s2 = new String(s);    //拷贝构造方法
        s3 = new String(charArray);    //以字符数组初始化字串
        //从字符数组第6个元素起取3个字符
        s4 = new String(charArray, 6, 3);
        s5 = new String(byteArray); //以字节数组初始化字串
        //从字节数组第4个元素起取4个字节
        s6 = new String(byteArray, 4, 4);
        //从StringBuffer对象中提取字符数据创建字串（注意,是复制）
        s7 = new String(buffer);
        //使用valueOf()系列方法，可以很方便地将各种类型的数据直接转换为字符串
        //将字符数组转换为字符串
        s8 = String.valueOf(charArray);
        //将double数值转换为字符串
        s9 = String.valueOf(100.0d);


        output = "s1 = " + s1 +
                "\ns2 = " + s2 +
                "\ns3 = " + s3 +
                "\ns4 = " + s4 +
                "\ns5 = " + s5 +
                "\ns6 = " + s6 +
                "\ns7 = " + s7 +
                "\ns8 = " + s8 +
                "\ns9 = " + s9;
        System.out.println(output);
    }

    //从字符串中提取字符数组
    static void stringAndArray() {
        String str = "你好，中国！";
        //将整个字符串中的所有字符都提取出来
        char[] charArray = str.toCharArray();
        //输出字符数组的内容
        printStringArray(charArray);
        char[] chars = new char[2];
        //从字符串中提取字符，构建字符数组
        //四个参数的含义
        //1.被拷贝字符在字串中的起始位置
        //2.被拷贝的最后一个字符在字串中的下标再加1
        //3.目标字符数组
        //4.拷贝的字符放在字符数组中的起始下标
        str.getChars(3, 5, chars, 0);
        printStringArray(chars);
    }

    //打印字符数组的内容
    static void printStringArray(char[] chars) {
        String output = "";
        for (int i = 0; i < chars.length; i++)
            output += "[" + i + "] " + chars[i] + "\n";
        System.out.println(output);
    }

    //重复拼接子串，生成新字符串
    static void stringRepeat() {
        String a5 = "a".repeat(5);
        //生成：aaaaa
        System.out.println(a5);
    }

    //字符串的拼接
    static void stringConcat() {
        String s1 = "Happy ", s2 = "Birthday";
        //使用concat方法将两个字符串连接为一个新的字符串
        System.out.println(s1.concat(s2)); //Happy Birthday
        //也可以使用“+”达到相同的目的
        System.out.println(s1 + s2); //Happy Birthday
        //"+"运算符可以将字符串与任意一个对象相拼接
        System.out.println("99+1=" + (99 + 1)); //99+1=100
        //当前时间：2020-10-01
        System.out.println("当前时间：" + LocalDate.now());
    }

    //字符串的“填充”
    static void stringFill() {

        var item = "Shirt";
        var size = "M";
        var price = 14.99;
        var color = "Red";

        var template = "Clothing item: %s, size %s, color %s, $%.2f";
        var itemString = String.format(template,
                item, size, color, price);
        //Clothing item: Shirt, size M, color Red, $14.99
        System.out.println(itemString);
    }

    //移除首尾的空白字符（JDK11）
    static void stringStrip() {
        String example = "  前后都有空白字符的字符串  ";
        System.out.println("|" + example.strip() + "|");
        System.out.println("|" + example.stripLeading() + "|");
        System.out.println("|" + example.stripTrailing() + "|");
    }

    //JDK 12：构建多行缩进的字符串
    static void stringIndent() {
        String star = "*";
        for (int i = 0; i < 5; i++) {
            System.out.print(star.indent(i));
        }
        for (int i = 4; i >= 0; i--) {
            System.out.print(star.indent(i));
        }
    }

    //判断字符串是否为空
    static void stringIsBlankOrEmpty() {
        var str = ""; //空串，其长度为0
        //isBlank: JDK11引入,用于检测字符串是否仅由
        // white space(即空白字符)构成
        System.out.println(str.isBlank());//true
        //isEmpty()，JDK 6引入，仅用于检测空串
        System.out.println(str.isEmpty());//true
        str = "   "; //全部由空格组成的字符串
        System.out.println(str.isBlank());//true
        System.out.println(str.isEmpty());//false
        //Tab，也算作空白字符
        str = "   ";
        System.out.println(str.isBlank());//true
        System.out.println(str.isEmpty());//false
        str = "\n"; //用于换行的格式控制字符，也算是空白符
        System.out.println(str.isBlank());//true
        System.out.println(str.isEmpty());//false
    }

    static void stringPool() {
        String s0 = "Hello";
        String s1 = "Hello";
        String s2 = "He" + "llo";
        System.out.println(s0 == s1);//true
        System.out.println(s0 == s2);//true

        String s3 = new String("Hello");
        String s4 = new String("Hello");
        System.out.println(s3 == s4);  // false
    }

    static void stringAssign() {
        String s1 = "a";
        String s2 = s1;
        System.out.println(s1 == s2); //true
        s1 += "b";
        System.out.println(s1 == s2); //false
        System.out.println(s1 == "ab"); //false
        System.out.println(s1.equals("ab")); //true
    }

    static void stringHashCode() {
        String s1 = "hello",
                s2 = "Hello",
                s3 = new String(s2);
        //hello的hashCode=99162322
        System.out.println(s1 + "的hashCode=" + s1.hashCode());

        //s2与s3引用不同的字符串对象
        System.out.println(s2 == s3);  //false
        //s2与s3所引用字符串对象的值相等
        System.out.println(s2.equals(s3)); //true

        //Hello的hashCode=69609650
        System.out.println(s2 + "的hashCode=" + s2.hashCode());
        //Hello的hashCode=69609650
        System.out.println(s3 + "的hashCode=" + s3.hashCode());

    }

    static void stringCompare() {

        var s1 = new String("hello");
        var s2 = new String("good bye");
        var s3 = new String("Happy Birthday");
        var s4 = new String("happy birthday");

        //使用字典法进行比较,返回0表两字串相等,小于返回负值,大于返回正值
        var output =
                "\ns1.compareTo( s2 ) is " + s1.compareTo(s2) +
                        "\ns2.compareTo( s1 ) is " + s2.compareTo(s1) +
                        "\ns1.compareTo( s1 ) is " + s1.compareTo(s1) +
                        "\ns3.compareTo( s4 ) is " + s3.compareTo(s4) +
                        "\ns4.compareTo( s3 ) is " + s4.compareTo(s3) +
                        "\n\n";
        System.out.println(output);

        //比较两字串中的某一部分是否相等
        //regionMatches方法参数的含义如下:
        //1.调用这个方法的字串中的起始下标
        //2.要比较的字串
        //3.要比较的字串的起始下标
        //4.要比较的字串比较的字符长度
        if (s3.regionMatches(0, s4, 0, 5))
            System.out.println("s3 和 s4 的前5个字符匹配\n");
        else
            System.out.println("s3 和 s4 的前5个字符不匹配");

    }

    static void stringIndex() {
        String letters = "abcdefghijklmabcdefghijklm";
        System.out.println(letters.indexOf('c')); //2
        //第2个参数是开始查找的起始下标
        System.out.println(letters.indexOf('c', 1));//2
        System.out.println(letters.indexOf('$'));//-1
        System.out.println(letters.lastIndexOf('c'));//15
        System.out.println(letters.lastIndexOf('m', 5));//-1
    }

    static void stringStartEnd() {
        String[] strings = {"started", "starting",
                "ended", "ending"};
        for (String string : strings) {
            if (string.startsWith("st"))
                System.out.println(string + "以st开头");
        }
        for (String string : strings) {
            if (string.endsWith("ed"))
                System.out.println(string + "以ed结尾");
        }
    }

    //提取子串
    static void stringSlice() {
        String letters = "abcdefghijklmabcdefghijklm";
        //输出：hijklm
        System.out.println(letters.substring(20));
        //输出：bcdef
        //(起始下标,要拷贝子串的最后下标加1但不包括该下标)
        System.out.println(letters.substring(1, 6) );
    }
}
