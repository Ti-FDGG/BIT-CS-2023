package string_buffer_demo;

import javax.swing.*;

public class UseStringBuffer {

    public static void main(String[] args) {
        //stringBufferConstructors();
        //stringBufferAppend();
        //stringBufferChars();
        stringBufferCapLen();
    }


    static void stringBufferConstructors() {
        //常用的三种StringBuffer构造方法
        var buf1 = new StringBuffer();
        var buf2 = new StringBuffer(10);
        var buf3 = new StringBuffer("hello");

        //使用toString()方法将字符串缓冲区中的字符提取出来
        System.out.println(buf1.toString());
        System.out.println(buf2.toString());
        System.out.println(buf3.toString());

    }

    static void stringBufferAppend() {
        var buf = new StringBuffer();
        //append()方法有多种重载形式，可接收多种类型的数据
        buf.append("hello\n");
        char[] charArray = {'a', 'b', 'c', 'd', 'e', 'f'};
        buf.append(charArray);
        buf.append("\n");
        buf.append(charArray, 0, 3);
        //append()方法支持级联调用
        buf.append("\n").append(true).append("\n")
                .append('Z').append("\n").append(100);
        //输出最终结果
        System.out.println(buf.toString());
    }

    static void stringBufferChars() {
        var buf = new StringBuffer("hello there");
        System.out.println("\nCharacter at 0: " + buf.charAt(0));
        buf.setCharAt(0, 'H');
        buf.setCharAt(6, 'T');
        System.out.println(buf.toString());
        //提取字符串缓冲区中的字符到字符数组中
        var charArray = new char[buf.length()];
        //(起始下标,长度,字符数组名,起始下标)
        buf.getChars(0, buf.length(), charArray, 0);
        for (int i = 0; i < charArray.length; ++i)
            System.out.print(charArray[i]+",");
        System.out.println();
        //reverse:倒转字串
        buf.reverse();
        System.out.println(buf.toString());
    }

    static void stringBufferCapLen() {

        var buf = new StringBuffer("Hello,");

        //length = 6
        System.out.println( "length = " + buf.length());
        //capacity = 22
        System.out.println("capacity = " + buf.capacity());
        //追加一个新的字符串
        buf.append("how are you?");
        //输出：Hello,how are you?
        System.out.println(buf.toString());
        //length = 18
        System.out.println( "length = " + buf.length());
        //capacity = 22
        System.out.println("capacity = " + buf.capacity());

        //ensureCapacity:保证StringBuffer的最小容量
        buf.ensureCapacity(75);
        //New capacity = 75
        System.out.println("New capacity = " + buf.capacity());

        //setLength:增大或减小StringBuffer的长度
        buf.setLength(10);
        System.out.println("New length = " + buf.length());
        //原有的内容被截断，输出：Hello,how
        System.out.println(buf.toString());
    }

}
