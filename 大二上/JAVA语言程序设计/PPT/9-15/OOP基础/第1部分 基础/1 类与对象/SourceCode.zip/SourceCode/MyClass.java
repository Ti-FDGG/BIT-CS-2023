/**
 * 自定义Java类的示例
 */
public class MyClass {
    //公有字段
    public String information = "";

    //自定义公有Java实例方法
    public void myMethod(String argu) {
        System.out.println(argu);
    }

    //region "属性 = 私有字段 + get方法 + set方法
    private int value;

    public int getValue() {
        return value;
    }

    public void setValue(int value) {
        this.value = value;
    }
    //endregion
}


class UseMyClass {
    public static void main(String[] args) {
        //创建类的实例
        MyClass obj = new MyClass();
        //通过对象变量调用类的公有方法
        obj.myMethod("Hello");
        //给属性赋值
        obj.setValue(100);
        //输出属性的当前值
        System.out.println(obj.getValue());
        //直接访问对象公有字段
        obj.information = "Information";
        //输出对象公有字段的当前值
        System.out.println(obj.information);
    }
}

