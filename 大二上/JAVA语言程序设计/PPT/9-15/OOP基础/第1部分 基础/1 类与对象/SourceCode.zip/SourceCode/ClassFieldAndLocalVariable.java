
public class ClassFieldAndLocalVariable {
    public static void main(String[] args) {
        var obj = new VariableAndField(10);
        obj.doSomething();
    }
}

class VariableAndField {
    private int x;

    public VariableAndField(int value) {
        this.x = value;
    }

    public void doSomething() {
        for (int x = 0; x < 5; x++) {
            System.out.println(x + " * " + x + " = " + x * x);
            //System.out.println(x + " * " + this.x + " = " + x * this.x);
        }
    }
}
