import java.util.Objects;

public class ObjectEquals {


    public static void main(String[] args) {
        MyTestClass obj1 = new MyTestClass(100);
        MyTestClass obj2 = new MyTestClass(100);

        System.out.println(obj1 == obj2);//false
        System.out.println(obj1.equals(obj2));//true

        boolean equalsResult = Objects.equals(obj1, obj2);
        //以下这句的输出结果，取决于MyTestClass是否重写了equals方法
        System.out.println(equalsResult); //false 或 true
    }

}

class MyTestClass {
    public int Value;

//    注意：只有参数类型为Object的，才是重写了Object的equals方法
//    参数类型为MyTestClass的，仅仅是Overload了equals方法。
//    这个方法是否被注释，会影响到Objects.equals的结果
//    @Override
//    public boolean equals(Object obj) {
//        return ((MyTestClass) obj).Value == this.Value;
//    }

    public boolean equals(MyTestClass obj) {
        return obj.Value == this.Value;
    }

    public MyTestClass(int initValue) {
        Value = initValue;
    }
}
