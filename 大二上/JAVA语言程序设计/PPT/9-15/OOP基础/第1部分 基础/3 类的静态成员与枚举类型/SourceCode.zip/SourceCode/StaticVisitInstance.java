/**
 * 静态方法如何访问实例字段？
 */
public class StaticVisitInstance {

    private int value = 100;

    private void increaseValue() {
        value++;
    }
    //只需要给静态方法传入一个对象引用，就能通过它访问到类的实例成员
    public static void staticMethodDemo(StaticVisitInstance obj) {
        obj.value = 1000;
        obj.increaseValue();
        System.out.println(obj.value);//1001
    }

    public static void main(String[] args) {
        staticMethodDemo(new StaticVisitInstance());
    }

}




