public class UseMyEnum {
    public static void main(String[] args) {
        //输出：ONE,TWO,THREE,
        for (MyEnum value : MyEnum.values()) {
            System.out.print(value + ",");
        }
    }
}

enum MyEnum {
    ONE, TWO, THREE
}


